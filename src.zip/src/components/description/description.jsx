import React from 'react'; 
import './description.css' 

const description = () => { 
  return ( 
    <div className="description"> 
      О наc     
    </div> 
  ); 
}; 
 
export default description;