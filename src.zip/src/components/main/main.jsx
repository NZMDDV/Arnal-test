import React from "react";
import './main.css'

const Main = () => {
    return (
        <div className="main">
            main
            
        </div>
    )
}

export default Main;