import React from 'react'; 
import './header.css' 
const Header = () => { 
 
     
 
  return ( 
    <div> 
      <span className="test"></span> 
    </div> 
  ); 
}; 
 
export default Header;